# Configuración Fastfetch - NGE / MAGI SYSTEM

Configuración de **fastfetch** con temática **Neon Genesis Evangelion** — HUD de NERV, paleta Unit-01 + NERV, etiquetas en japonés e inglés.

## Requisitos

- `fastfetch` ≥ 2.x

## Instalación (local)

```bash
# Crear directorio de configuración si no existe
mkdir -p ~/.config/fastfetch

# Copiar la configuración
cp nge.jsonc ~/.config/fastfetch/config.jsonc
```

## Uso

```bash
fastfetch
```

O usando este archivo directamente sin instalarlo:

```bash
fastfetch --config nge.jsonc
```

## Módulos incluidos

| Sección | Módulos |
|---------|---------|
| PILOT | User@Host |
| SYSTEM | OS, Kernel, Uptime, Packages, Shell, WM, Terminal |
| HARDWARE | CPU, GPU, RAM, Disk, Battery, Display |
| EXTRAS | Date, Loadavg, Processes, Sync, Palette |

Además incluye banners custom de estilo HUD de NERV (`NERV`, `MAGI SYSTEM // TOKYO-3`, `AT FIELD`, `PATTERN: BLUE`).

## Archivos

- `nge.jsonc` — configuración principal de fastfetch (formato JSONC con comentarios)

## Personalización

Edita `nge.jsonc` para ajustar colores, módulos o el banner ASCII. Sigue el esquema oficial de fastfetch:

https://github.com/fastfetch-cli/fastfetch/raw/dev/doc/json_schema.json

---

Hecho con ❤️ por facu
